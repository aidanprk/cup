class Class{
	constuctor(name){
		
	}
}

